package com.damu.training;

public abstract class Instrument {
	public abstract void play();
}
