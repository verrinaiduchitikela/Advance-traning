
public class Rectangle {
double length;
	double breadth;
	public Rectangle(double l,double b) {
		length=l;
		breadth=b;
	}
	public double getarea() {
		return length*breadth;
	}

}
